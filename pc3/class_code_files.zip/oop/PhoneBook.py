####################################################################################################################
###                                    Algorithms for Bioinformatics
###                                 ***  class Phone Book              ***
###
### Test number: 4      Class Number: 3         Date:   2022
###
### Group
### Student: ....               Number:...
### Student: ....               Number:...
###
####################################################################################################################
### Complete the code below for the object PhoneBook
### In main give example on how to create, update, insert and use object PhoneBook
### Explain in comments how the data will be organized

class PhoneBook:
    ''' Implements a Phone Book '''

    def __init__(self):
        ''' initializes phone book with appropriate data structure '''
        # complete
        # ...

    def add_phone(self, name, number):
        # complete
        # ...

    # add the remaining methods here


if __name__ == "__main__":
    ''' test code here '''
    # complete
    # ...
